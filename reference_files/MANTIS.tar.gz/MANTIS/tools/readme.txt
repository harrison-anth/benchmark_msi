This folder will contain useful tools and code snippets for MANTIS.
