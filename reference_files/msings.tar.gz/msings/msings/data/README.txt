this directory will contain unversioned files containing git version info
